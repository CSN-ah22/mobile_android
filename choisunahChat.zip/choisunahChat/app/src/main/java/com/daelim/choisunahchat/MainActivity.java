package com.daelim.choisunahchat;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;

import org.java_websocket.client.WebSocketClient;
import org.java_websocket.handshake.ServerHandshake;

import java.net.URI;

public class MainActivity extends AppCompatActivity {
    private String login_id;
    private String login_pw;
    WebSocketClient ws;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        login_id = getIntent().getStringExtra("id");
        login_pw = getIntent().getStringExtra("pw");

        try {
            ws  = new WebSocketClient(new URI("ws://61.83.168.88:4877")) {
                @Override
                public void onOpen(ServerHandshake serverHandshake) {
                    Log.e("!!!", "onOpen");
                    ws.send("login_id : " + login_id);
                }

                @Override
                public void onMessage(String s) {
                    Log.e("!!!", "onMessage S : " + s);
                }

                @Override
                public void onClose(int i, String s, boolean b) {
                    Log.e("!!!", "onClose" + s);
                }

                @Override
                public void onError(Exception e) {
                    Log.e("!!!", "onError");
                    e.printStackTrace();
                }
            };

            ws.connect();
        }catch (Exception e){
            e.printStackTrace();
        }


    }
}