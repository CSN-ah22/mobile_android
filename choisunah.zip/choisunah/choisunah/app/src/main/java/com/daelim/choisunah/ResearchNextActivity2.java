package com.daelim.choisunah;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.RadioGroup;
import android.widget.Toast;

import java.util.ArrayList;

public class ResearchNextActivity2 extends AppCompatActivity {

    private RadioGroup rg_content;
    private String preDate;
    private String color;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_research_next2);

        //이전 페이지값 받아오기
        preDate = getIntent().getStringExtra("data");
        Log.e("!!!!", "" + preDate);

        rg_content = findViewById(R.id.rg_content);

        //리스트에 추가
        ArrayList<String> data = new ArrayList<>();
        data.add(preDate);

        rg_content.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int i) { //매개변수 i는 선택이된 항목의 id값

                switch (i) {
                    case R.id.color_red:
                        Toast.makeText(ResearchNextActivity2.this, "빨강을 선택했습니다", Toast.LENGTH_SHORT).show();
                        color = "red";
                        break;
                    case R.id.color_yellow:
                        Toast.makeText(ResearchNextActivity2.this, "노랑을 선택했습니다", Toast.LENGTH_SHORT).show();
                        color = "yellow";
                        break;
                    case R.id.color_black:
                        Toast.makeText(ResearchNextActivity2.this, "검정을 선택했습니다", Toast.LENGTH_SHORT).show();
                        color = "black";
                        break;
                    case R.id.color_blue:
                        Toast.makeText(ResearchNextActivity2.this, "파랑을 선택했습니다", Toast.LENGTH_SHORT).show();
                        color = "blue";
                        break;
                }
            }
        });



        Button bt_next = findViewById(R.id.bt_next);
        bt_next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(ResearchNextActivity2.this, ResearchNextActivity3.class);
                intent.putExtra("color",color);
                intent.putExtra("data",preDate);
                startActivity(intent);
                finish();
            }
        });

    }
}