package com.daelim.choisunah;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;

import com.daelim.choisunah.R;

public class SplahActivity extends AppCompatActivity {

    private  SplahActivity activity;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splah);
        activity = this;
    }

    @Override
    protected void onStart() {
        Handler h = new Handler();
        Intent intent = new Intent(activity, InitActivity.class);
        h.postDelayed(new Runnable() {
            @Override
            public void run() {
                startActivity(intent);
            }
        }, 2000);
        super.onStart();
    }

    @Override
    protected void onStop() {
        super.onStop();
    }
}