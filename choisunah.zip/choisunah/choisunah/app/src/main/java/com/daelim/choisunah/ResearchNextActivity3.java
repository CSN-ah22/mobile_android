package com.daelim.choisunah;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.RadioGroup;
import android.widget.Toast;

public class ResearchNextActivity3 extends AppCompatActivity {

    private RadioGroup rg_content;
    private String preDate;
    private String color;
    private String pattern;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_research_next3);

        //이전 페이지값 불러오기
        preDate = getIntent().getStringExtra("data");
        Log.e("!!!!", "" + preDate);
        color = getIntent().getStringExtra("color");
        Log.e("!!!!", "" + color);

        //라디오
        rg_content = findViewById(R.id.rg_content);

        rg_content.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int i) { //매개변수 i는 선택이된 항목의 id값

                switch (i) {
                    case R.id.pattern_hoppy:
                        Toast.makeText(ResearchNextActivity3.this, "호피무늬를 선택했습니다", Toast.LENGTH_SHORT).show();
                        pattern = "hoppy";
                        break;
                    case R.id.pattern_check:
                        Toast.makeText(ResearchNextActivity3.this, "체크무늬를 선택했습니다", Toast.LENGTH_SHORT).show();
                        pattern = "check";
                        break;
                    case R.id.pattern_flower:
                        Toast.makeText(ResearchNextActivity3.this, "꽃무늬 선택했습니다", Toast.LENGTH_SHORT).show();
                        pattern = "flower";
                        break;
                    case R.id.pattern_dot:
                        Toast.makeText(ResearchNextActivity3.this, "점무늬 선택했습니다", Toast.LENGTH_SHORT).show();
                        pattern = "dot";
                        break;
                }
            }
        });

        Button bt_next = findViewById(R.id.bt_next);
        bt_next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(ResearchNextActivity3.this, ResearchNextActivity4.class);
                intent.putExtra("pattern",pattern);
                intent.putExtra("color",color);
                intent.putExtra("data",preDate);
                startActivity(intent);
                finish();
            }
        });

    }
}