package com.daelim.choisunah;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;

public class ResearchResult extends AppCompatActivity {
    private String preDate;
    private String color;
    private String pattern;
    private String box;
    private TextView order_box;
    private TextView order_size;
    private TextView order_color;
    private TextView order_pattern;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_research_result);

        preDate = getIntent().getStringExtra("data");
        Log.e("!!!!", "" + preDate);
        color = getIntent().getStringExtra("color");
        Log.e("!!!!", "" + color);
        pattern = getIntent().getStringExtra("pattern");
        Log.e("!!!!", "" + pattern);
        box = getIntent().getStringExtra("box");
        Log.e("!!!!", "" + box);

        order_size = findViewById(R.id.order_size);
        order_size.setText(preDate);

        order_color = findViewById(R.id.order_color);
        order_color.setText(color);

        order_pattern = findViewById(R.id.order_pattern);
        order_pattern.setText(pattern);

        order_box = findViewById(R.id.order_box);
        order_box.setText(box);
    }
}