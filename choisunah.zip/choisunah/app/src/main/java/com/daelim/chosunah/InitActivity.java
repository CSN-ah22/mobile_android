package com.daelim.chosunah;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class InitActivity extends AppCompatActivity {

    //setTopBox, radio


    private  InitActivity activity;
    Button cal;
    Button next;
    Button list;
    Button listCustom;
    TextView result;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_init);
        activity = this;
    }

    @Override
    protected void onStart() {
        super.onStart();
        result=findViewById(R.id.result);
        cal=findViewById(R.id.cal);
        cal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(activity, CalActivity.class);
                startActivity(intent);
            }
        });
        next=findViewById(R.id.next);
        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(activity, NextActivity.class);
                startActivity(intent);
            }
        });
        list=findViewById(R.id.list);
        list.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(activity, ListActivity.class);
                startActivity(intent);
            }
        });
        listCustom = findViewById(R.id.listCustom);
        listCustom.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(activity, ListCustomActivity.class);
                startActivity(intent);
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        String result2 = data.getExtras().getString("data");
        result.setText(result2);
    }


}