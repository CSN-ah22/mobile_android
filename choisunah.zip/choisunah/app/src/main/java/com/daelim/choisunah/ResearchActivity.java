package com.daelim.choisunah;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioGroup;

public class ResearchActivity extends AppCompatActivity {


    private RadioGroup size_content;
    private String size = "";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_research);


        //라디오

        size_content = findViewById(R.id.size_content);

        size_content.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int i) {
                switch (i) {

                    case R.id.size_235:
                        size = "235";
                        break;
                    case R.id.size_240:
                        size = "240";
                        break;
                    case R.id.size_245:
                        size = "245";
                        break;
                    case R.id.size_250:
                        size = "250";
                        break;
                }
            }
        });

        Button bt_next = findViewById(R.id.bt_next);
        bt_next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                //값 넘기기
                Intent intent = new Intent(ResearchActivity.this, ResearchNextActivity2.class);
                intent.putExtra("data",size);
                startActivity(intent);
                finish();
            }
        });
    }
}