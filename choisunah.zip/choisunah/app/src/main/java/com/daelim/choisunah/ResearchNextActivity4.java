package com.daelim.choisunah;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;

public class ResearchNextActivity4 extends AppCompatActivity {

    private CheckBox cb_a,cb_b,cb_c;
    private String preDate;
    private String color;
    private String pattern;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_research_next4);

        //이전 페이지값 불러오기
        preDate = getIntent().getStringExtra("data");
        Log.e("!!!!", "" + preDate);
        color = getIntent().getStringExtra("color");
        Log.e("!!!!", "" + color);
        pattern = getIntent().getStringExtra("pattern");
        Log.e("!!!!", "" + pattern);

        //체크
        cb_a = findViewById(R.id.cb_a);
        cb_b = findViewById(R.id.cb_b);
        cb_c = findViewById(R.id.cb_c);

//        cb_a.setChecked(true);

        //체크
        Log.e("!!!", "cb_a: " + cb_a.isChecked());
        Log.e("!!!", "cb_b: " + cb_b.isChecked());
        Log.e("!!!", "cb_c: " + cb_c.isChecked());


        Button bt_next = findViewById(R.id.bt_next);
        bt_next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String box = "";

                //특정 항목이 체크되어있는지를 확인
                if(cb_a.isChecked()){
                    box = box + "문 앞으로 배송해주세요";
                }
                if(cb_b.isChecked()){
                    if (box.length() > 0){
                        box = box + ", 안심번호 사용";
                    }else{
                        box = box + "안심번호 사용";
                    }
                }
                if(cb_c.isChecked()){
                    if (box.length() > 0){
                        box = box + ", 배송완료 문자 보내주세요";
                    }else{
                        box = box + "배송완료 문자 보내주세요";
                    }
                }

                Log.e("!!!", "cb_a: " + cb_a.isChecked());
                Log.e("!!!", "cb_b: " + cb_b.isChecked());
                Log.e("!!!", "cb_c: " + cb_c.isChecked());
                Log.e("!!!", "box: " + box);

                //값 넘기기
                Intent intent = new Intent(ResearchNextActivity4.this, ResearchResult.class);
                intent.putExtra("pattern",pattern);
                intent.putExtra("color",color);
                intent.putExtra("data",preDate);
                intent.putExtra("box",box);
                startActivity(intent);
                finish();
            }
        });
    }
}