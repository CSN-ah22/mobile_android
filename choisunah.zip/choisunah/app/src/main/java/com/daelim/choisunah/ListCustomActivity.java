package com.daelim.choisunah;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import com.daelim.choisunah.R;
import com.daelim.choisunah.data.ListData;

import java.util.ArrayList;

public class ListCustomActivity extends AppCompatActivity {
    private ArrayList<ListData> list;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_custom);

        list = new ArrayList<>();
        list.add(new ListData("짱구","010-9999-9999",true));
        list.add(new ListData("짱아","010-9889-9889",true));
        list.add(new ListData("가나","010-2323-2323", false));

        ListView lv_data = findViewById(R.id.lv_data);
        lv_data.setAdapter(new BaseAdapter() {
            @Override
            public int getCount() {
                return list.size();
            }

            @Override
            public Object getItem(int i) {
                return null;
            }

            @Override
            public long getItemId(int i) {
                return 0;
            }

            @Override
            public View getView(int i, View view, ViewGroup viewGroup) {
                view = getLayoutInflater().inflate(R.layout.list_custom_item,viewGroup,false);
                TextView tv_1 = view.findViewById(R.id.tv_1);
                TextView tv_2 = view.findViewById(R.id.tv_2);
                ImageView iv_image = view.findViewById(R.id.iv_image);
                tv_1.setText(list.get(i).getData1());
                tv_2.setText(list.get(i).getData2());
                if(list.get(i).isBool()){
                    iv_image.setImageResource(R.drawable.man);
                }else {
                    iv_image.setImageResource(R.drawable.woman);
                }
                return view;
            }
        });
    }
}