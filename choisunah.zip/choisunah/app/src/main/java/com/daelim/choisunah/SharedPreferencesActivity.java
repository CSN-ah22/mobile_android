package com.daelim.choisunah;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class SharedPreferencesActivity extends AppCompatActivity {

    EditText editText;
    Button save;
    Button resultCheck;
    TextView textView;
    String result;
    SharedPreferences preferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_shared_preferences);

        //저장 버튼 값 확인 버튼
        //edittext 내용을 SharedPreferences에 저장하고 비운다
        //값 확인 버튼을 누르면 SharedPreferences에서 꺼내온다
        //alert로 띄운다

        editText = findViewById(R.id.editText);
        save = findViewById(R.id.save);
        resultCheck = findViewById(R.id.resultCheck);
        textView= findViewById(R.id.textView);

        preferences = getSharedPreferences("edit_result", MODE_PRIVATE);

        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                SharedPreferences.Editor editor = preferences.edit();
                editor.putString("result",editText.getText().toString());
                editor.commit();
                editText.setText("");
            }
        });
        resultCheck.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                getPreferences();
            }
        });

    }

    private void getPreferences(){
        textView.setText("edit_result = " + preferences.getString("result",""));

        AlertDialog.Builder myAlertBuilder =
                new AlertDialog.Builder(SharedPreferencesActivity.this);
        myAlertBuilder.setTitle("Alert");
        myAlertBuilder.setMessage(preferences.getString("result",""));
        myAlertBuilder.setNegativeButton("OK!", new DialogInterface.OnClickListener() {
            @Override public void onClick(DialogInterface dialogInterface, int i)
            { }
        });

        AlertDialog msgDlg = myAlertBuilder.create();
        msgDlg.show();

    }


}