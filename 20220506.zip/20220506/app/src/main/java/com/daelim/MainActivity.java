package com.daelim;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private String login_id;
    private String login_pw;
    TextView nick_name;
    Button my_introduce;
    Button my_photo;
    Button my_class;
    Button my_gugudan;
    Button preferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        //sharedpreference로 변경
        login_id = getIntent().getStringExtra("id");
        login_pw = getIntent().getStringExtra("pw");

        nick_name = findViewById(R.id.nick_name);
        nick_name.setText("어서오세요"+login_id+"님");

        my_introduce = findViewById(R.id.my_introduce);
        my_introduce.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, MyIntroduceActivity.class);
                startActivity(intent);
                finish();
            }
        });

        my_gugudan = findViewById(R.id.my_gugudan);
        my_gugudan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, MyGugudanActivity.class);
                startActivity(intent);
                finish();
            }
        });

        preferences = findViewById(R.id.preferences);
        preferences.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, PreferencesActivity.class);
                intent.putExtra("current_nickname",nick_name.getText().toString());
                intent.putExtra("current_pw",login_pw);
                startActivity(intent);
                finish();
            }
        });
    }
}