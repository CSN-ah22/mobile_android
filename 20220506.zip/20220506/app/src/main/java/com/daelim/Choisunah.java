package com.daelim;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Parcelable;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class Choisunah extends AppCompatActivity {

    private Choisunah activity;
    Button login;
    EditText login_id;
    EditText login_pw;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    @Override
    protected void onStart() {
        super.onStart();

       login_id = (EditText) findViewById(R.id.login_id);
        login_pw = (EditText) findViewById(R.id.login_pw);


        login=findViewById(R.id.login);
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Choisunah.this, MainActivity.class);
                //sharedpreference로 변경
                intent.putExtra("id", login_id.getText().toString());
                intent.putExtra("pw",login_pw.getText().toString());
                startActivity(intent);
                finish();
            }
        });
    }

}