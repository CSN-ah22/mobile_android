package com.daelim;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class MyGugudanActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_gugudan);
    }
}