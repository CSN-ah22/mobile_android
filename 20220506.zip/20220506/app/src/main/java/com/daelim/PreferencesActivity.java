package com.daelim;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class PreferencesActivity extends AppCompatActivity {

    String current_pw;
    String current_nickname;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_preferences);

        //비밀번호 변경
        //현재의 비밀번호값 가져오기
        //sharedpreference로 변경
        current_pw = getIntent().getStringExtra("current_pw");
        //비밀번호 버튼 누를시 비밀번호 변경 화면으로 이동

        //닉네임 설정
        //현재의 닉네임 가져오기
        //sharedpreference로 변경
        current_nickname = getIntent().getStringExtra("current_nickname");
        //닉네임 설정 화면으로 이동



    }
}